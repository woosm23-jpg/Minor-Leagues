import fs from 'node:fs';
const p='reports/v50-phase-c-actions-audit.json';
const r=JSON.parse(fs.readFileSync(p,'utf8'));
const failures=[];
const must=(ok,msg)=>{if(!ok)failures.push(msg);};
must(r.players===5429,`expected 5429 players, got ${r.players}`);
must(r.baseHash===r.patchHash,`base/patch hash mismatch ${r.baseHash} vs ${r.patchHash}`);
must((r.finiteErrors?.phaseB?.length??1)===0,'Phase B contains non-finite values');
must((r.finiteErrors?.phaseC?.length??1)===0,'Phase C contains non-finite values');
must((r.arsenalGate?.usageBad??1)===0,`pitch arsenal usage-sum errors: ${r.arsenalGate?.usageBad}`);
must((r.arsenalGate?.stuffMissing??1)===0,`pitchers with missing Stuff: ${r.arsenalGate?.stuffMissing}`);
must(r.trackingRows>=14000,`tracking coverage unexpectedly low: ${r.trackingRows}`);
must(r.pitchArsenalRows>=11000,`arsenal coverage unexpectedly low: ${r.pitchArsenalRows}`);
for(const level of ['AA','HIGH_A','A']){
  const s=r.deltaByLevel?.[level];
  must(s&&Math.abs(Number(s.min))<1e-9&&Math.abs(Number(s.max))<1e-9,`${level} changed despite no level tracking: min=${s?.min} max=${s?.max}`);
}
const mlb=r.deltaByLevel?.MLB, aaa=r.deltaByLevel?.AAA;
must(mlb&&Math.max(Math.abs(mlb.min),Math.abs(mlb.max))<=12,`MLB max absolute OVR delta > 12: min=${mlb?.min} max=${mlb?.max}`);
must(aaa&&Math.max(Math.abs(aaa.min),Math.abs(aaa.max))<=8,`AAA max absolute OVR delta > 8: min=${aaa?.min} max=${aaa?.max}`);
must((r.thresholds?.['15']??999)===0,`players with |OVR delta| >=15: ${r.thresholds?.['15']}`);
must((r.runtimeMs?.phaseC??999999)<120000,`Phase C inference too slow: ${r.runtimeMs?.phaseC}ms`);
console.log('MODEL',r.modelId);
console.log('PLAYERS',r.players,'TRACKING',r.trackingRows,'ARSENAL',r.pitchArsenalRows);
console.log('RUNTIME_MS',JSON.stringify(r.runtimeMs));
console.log('THRESHOLDS',JSON.stringify(r.thresholds));
console.log('MLB_DELTA',JSON.stringify(mlb));
console.log('AAA_DELTA',JSON.stringify(aaa));
console.log('TOP_UP',r.topUp.slice(0,12).map(x=>`${x.name}:${x.delta}`).join(' | '));
console.log('TOP_DOWN',r.topDown.slice(0,12).map(x=>`${x.name}:${x.delta}`).join(' | '));
if(failures.length){console.error('\nPHASE_C_ACTIONS_GATE_FAIL');for(const f of failures)console.error('- '+f);process.exit(1);}else{console.log('\nPHASE_C_ACTIONS_GATE_PASS');}
