THE CALL-UP v50 Phase C validator bundle.
Generated from the current local v50 rating engine (Current Ability model c7).
The GitHub workflow unpacks this bundle and validates the repository's official Snapshot v2 + Phase C data.
